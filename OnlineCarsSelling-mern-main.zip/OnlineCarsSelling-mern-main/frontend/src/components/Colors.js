const Colors = {
    orange:'#F57C00',
    DarkBlue:'rgb(26 33 56)',
    BWhite:'#FFFFFF',
    BDark:'#171C28',
    Black:'#2D3748',
    white:'#EEEEEF',
    lightWhite:'#AEB0B4',
    SubBlack:'#646E73',
    SubWhite:'#AEB0B4',
    medium: "#6e6969",
    light: "#f8f4f4",
    dark: "#0c0c0c",
    danger: "#ff5252",
    blue:'#1976D2'
}
export default Colors;